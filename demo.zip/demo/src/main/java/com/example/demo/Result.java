package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Result {
	
	

	public String address;
	public String status;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
	 
	

}


